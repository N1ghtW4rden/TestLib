//
//  ViewController.swift
//  TestCocoaPodsLib
//
//  Created by Горохов Никита Исип20 on 11.04.2022.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    struct Info {
        
        var firstName = ""
        var secondName = ""
        var description = ""
        var urlImage = ""
        
    }
    
    var infoArray: [Info] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        getInfo()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return infoArray.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        cell.firstNameLabel.text = infoArray[indexPath.row].firstName
        cell.secondNameLabel.text = infoArray[indexPath.row].secondName
        cell.descriptionLabel.text = infoArray[indexPath.row].description
        
        var url = URL(string: infoArray[indexPath.row].urlImage)
        if let data = try? Data(contentsOf: url!) {
            cell.iconImageView.image = UIImage(data: data)
        }

        // Configure the cell...

        return cell
    }
    
    func getInfo() {
        
        let url = "http://mad2019.hakta.pro/api/wanted"
        
        AF.request(url, method: .get).validate().responseJSON { response in
            
            switch response.result {
                
            case .success(let value):
                let json = JSON(value)
                for i in 0..<json["data"].count {
                    self.infoArray.append(Info(firstName: json["data"][i]["first_name"].stringValue, secondName: json["data"][i]["last_name"].stringValue, description: json["data"][i]["description"].stringValue, urlImage: json["data"][i]["photo"].stringValue))
                }
                self.tableView.reloadData()
                print("JSON: \(json)")
                
            case .failure(let error):
                print(error)
            }
        }
        
    }

}

